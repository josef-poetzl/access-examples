Files:
- DeclDict.accda .. add-in 
- DeclDictTester.accdb .. test file

Note:
Open DeclDictTester.accdb and start add-in (see codemodule _LoadAddIn)
